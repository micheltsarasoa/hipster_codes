package com.example.pagesproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
